import React, { Component } from "react";
const pokeApi = "http://assets.pokemon.com/assets/cms2/img/pokedex/detail/";

class PokeCard extends Component {
  render() {
    const { img, pos } = this.props;
    return (
      <div className="pokemon">
        <p>Name: {pokemons[pos].name}</p>
        <p>Type: {pokemons[pos].type}</p>
        <img alt="pokemon" src={`${pokeApi}${img}.png`} />
        <p>Experience: {pokemons[pos].base_experience}</p>
      </div>
    );
  }
}

export default PokeCard;
