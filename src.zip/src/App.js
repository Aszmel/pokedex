import React, { Component } from "react";
import "./App.css";
import PokeList from "./PokeList";

class App extends Component() {
  static defaultProps = {
    pokemons: [
      { id: 4, name: "Charmander", type: "fire", base_experience: 62 },
      { id: 7, name: "Squirtle", type: "water", base_experience: 63 },
      { id: 11, name: "Metapod", type: "bug", base_experience: 72 },
      { id: 12, name: "Butterfree", type: "flying", base_experience: 168 },
      { id: 25, name: "Pikachu", type: "electric", base_experience: 112 },
      { id: 39, name: "Jiglypuff", type: "normal", base_experience: 95 },
      { id: 94, name: "Gengar", type: "poison", base_experience: 225 },
      { id: 133, name: "Eevee", type: "normal", base_experience: 65 }
    ]
  };
  render() {
    <div className="root">
      <h1>Pokedex game</h1>
      <h2>Winner</h2>
      <p>Sum of experience is: </p>
      <PokeList />
      <h2>Loser</h2>
      <p>Sum of experience is: </p>
      <PokeList />
    </div>;
  }
}

export default App;
